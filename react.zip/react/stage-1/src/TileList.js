import React from 'react';
class TileList extends React.Component{
state={
  name:"somany",model:"nit-01",price:200,rating:2,status:1
}
render(){
  return(<div>
      <div>
      {this.state.name}</div>

      <div>
      {this.state.model}
      </div>

      <div>
      {this.state.price}
      </div>

      <div>
      {this.state.status}
      </div>

</div>);
}
}
export default TileList;
