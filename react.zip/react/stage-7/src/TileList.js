import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Tile from './Tile';

function TilesList() {
  const [tiles, setTiles] = useState([]);
  return (
    <div className='container'>
      <div className="card">
        <div className="card-header bg-primary text-white">Tileskart</div>
        <div className="card-body">
          <table className="table">
            <thead>
              <tr>
                <th>Images</th>
                <th>name</th>
                <th>model</th>
                <th>price</th>
                <th>rating</th>
                <th>status</th>
              </tr>
            </thead>
            <tbody>
              {tiles.map((tile, index) => {
                return (
                  <Tile tile={tile} key={index} />
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="card-footer"></div>
      </div>
    </div>
  );
}

export default TilesList;


