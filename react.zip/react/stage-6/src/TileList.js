import React from 'react';
import axios from 'axios';
import Tile from './Tile'
import './Tile.css';
class TilesList extends React.Component {

    state = {
    tiles: [],
    search:''
  };


  componentDidMount() {
    axios.get(`http://demo5911200.mockable.io/tiles`)
      .then(res => {
        const tiles = res.data;
        this.setState({ tiles });
      })
  }
  updateSearch(event){
    this.setState({search:event.target.value.substr(0,20)});
  }
  


 render() {
  let filteredTiles = this.state.tiles.filter(
    (tile)=>{
      return tile.name.toLowerCase().indexOf(this.state.search.toLowerCase())!==-1;
    }
  );
  return (
   <div className='container'>
   <div className="card">
   <div className="card-header bg-primary text-white">Tileskart</div>
   <div className="card-body">
   <div className='filter' >
         <input type="text"
               value={this.state.search}
               size="30" 
               onChange={this.updateSearch.bind(this)} placeholder="Enter tile name to search..."  />
               <i className="fa fa-search" ></i>
                </div>
   <table className="table">
         <thead>
           <tr>
             <th>Images</th>
             <th>name</th>
             <th>model</th>
             <th>price</th>
             <th>rating</th>
             <th>status</th>
           </tr>
         </thead>
         <tbody>
         {filteredTiles.map((tile,index)=> {
             return (
               <Tile tile={tile} key={index}/>
             );
           })}
         </tbody>
       </table>
     </div>
   <div className="card-footer bg-primary"></div>
 </div> 
</div>

   );
 }
}


export default TilesList;


