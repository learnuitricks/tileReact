const express=require('express');
var cors = require('cors');
const app=express();
app.use(cors());
app.get('/api/tiles',(req,res)=>{
    const tiles=[
        {"name":"somany","model":"nit-01","price":200,"rating":2,"image":"tile1.jpg","status":1,"Id":1},
        {"name":"johnson","model":"nit-02","price":100,"rating":4,"image":"tile2.jpg","status":0,"Id":2},
        {"name":"hsil","model":"nit-03","price":150,"rating":5,"image":"tile3.jpg","status":1,"Id":3},
        {"name":"clayhaus","model":"nit-04","price":350,"rating":3,"image":"tile4.jpg","status":1,"Id":4},
        {"name":"haktai","model":"nit-05","price":150,"rating":5,"image":"tile5.jpg","status":0,"Id":5},
        {"name":"kajaria","model":"nit-06","price":450,"rating":2,"image":"tile6.jpg","status":1,"Id":6},
      ];
      res.json(tiles);
});

const port=5000;
app.listen(port,()=>console.log(`server started on prt ${port}`));