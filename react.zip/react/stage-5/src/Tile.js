import React from 'react'
class Tile extends React.Component{
render() {
     return (
    <>
               <tr>
               <td><img src={require(`./assets/images/tiles/${this.props.tile.image}`)} alt='no'/></td>   
               <td>{this.props.tile.name}</td>
               <td>{this.props.tile.model}</td>
               <td>{this.props.tile.price}</td>
               <td>{this.props.tile.rating}</td>
               <td>{this.props.tile.status}</td>
               </tr>
       </>   
     )}
}
export default Tile;

